import { useState, useCallback, useEffect } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createTranscription } from "@/lib/api";
import { Navbar } from "@/components/layout/navbar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { createGroqClient } from "@/lib/groq-client";
import { 
  Upload, 
  FileAudio, 
  X, 
  Play, 
  Pause, 
  Loader2, 
  Copy, 
  Check,
  Download,
  Wand2
} from "lucide-react";

export default function Transcribe() {
  const [file, setFile] = useState<File | null>(null);
  const [transcription, setTranscription] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const saveTranscriptionMutation = useMutation({
    mutationFn: createTranscription,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transcriptions"] });
      toast({
        title: "Salvo com Sucesso",
        description: "Transcrição salva no histórico.",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const selectedFile = acceptedFiles[0];
    if (selectedFile) {
      setFile(selectedFile);
      const url = URL.createObjectURL(selectedFile);
      setAudioUrl(url);
      setTranscription("");
      setProgress(0);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a', '.ogg', '.flac']
    },
    maxFiles: 1
  });

  useEffect(() => {
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.onended = () => setIsPlaying(false);
      setAudioElement(audio);
      return () => {
        audio.pause();
        URL.revokeObjectURL(audioUrl);
      };
    }
  }, [audioUrl]);

  const togglePlayback = () => {
    if (!audioElement) return;
    if (isPlaying) {
      audioElement.pause();
    } else {
      audioElement.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleTranscribe = async () => {
    if (!file) return;
    
    // Use stored key or fallback to the provided demo key
    const apiKey = localStorage.getItem("groq_api_key") || "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";
    
    if (!apiKey) {
      toast({
        variant: "destructive",
        title: "Chave API ausente",
        description: "Por favor, configure sua chave API Groq nas configurações primeiro.",
      });
      return;
    }

    setIsProcessing(true);
    setProgress(10);

    try {
      // Mock progress animation
      const interval = setInterval(() => {
        setProgress(p => Math.min(p + 5, 90));
      }, 500);

      const groq = createGroqClient(apiKey);
      
      // Using Groq's Whisper model - using universal model for multilingual support
      const translation = await groq.audio.transcriptions.create({
        file: file,
        model: "whisper-large-v3", // Changed to whisper-large-v3 for better multilingual support
        response_format: "json",
        temperature: 0.0,
        language: "pt" // Hint for Portuguese
      });

      clearInterval(interval);
      setProgress(100);
      setTranscription(translation.text);
      
      // Auto-save transcription
      saveTranscriptionMutation.mutate({
        fileName: file.name,
        fileSize: (file.size / (1024 * 1024)).toFixed(2) + " MB",
        transcriptionText: translation.text,
        model: "whisper-large-v3",
        wordCount: translation.text.split(" ").length.toString(),
      });
      
      toast({
        title: "Transcrição Completa",
        description: "Seu áudio foi processado com sucesso e salvo.",
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Falha na Transcrição",
        description: "Falha ao transcrever áudio. Tente novamente.",
      });
      setProgress(0);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(transcription);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([transcription], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `transcricao-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const clearFile = () => {
    setFile(null);
    setAudioUrl(null);
    setTranscription("");
    setProgress(0);
    if (audioElement) {
      audioElement.pause();
    }
    setIsPlaying(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/20 pb-20">
      <Navbar />
      
      <main className="container max-w-5xl mx-auto px-4 py-12">
        <div className="text-center mb-12 space-y-4">
          <h2 className="text-5xl font-bold tracking-tight bg-gradient-to-b from-foreground to-muted-foreground bg-clip-text text-transparent font-display">
            Áudio para Texto
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Transcrição precisa e segura com a tecnologia Trust AI.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column: Upload & Preview */}
          <div className="space-y-6">
            {!file ? (
              <div
                {...getRootProps()}
                className={`
                  border-2 border-dashed rounded-3xl h-80 flex flex-col items-center justify-center p-8 text-center cursor-pointer transition-all duration-300
                  ${isDragActive 
                    ? "border-primary bg-primary/5 scale-[0.99]" 
                    : "border-border/60 hover:border-primary/50 hover:bg-muted/30 hover:scale-[1.01]"
                  }
                `}
              >
                <input {...getInputProps()} />
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6 ring-1 ring-primary/20 shadow-lg shadow-primary/5">
                  <Upload className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">
                  {isDragActive ? "Solte o áudio aqui" : "Arraste e solte o áudio"}
                </h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Suporta MP3, WAV, M4A (Máx 25MB)
                </p>
                <Button className="rounded-full px-8">Selecionar Arquivo</Button>
              </div>
            ) : (
              <Card className="p-6 border-border/50 space-y-6 rounded-3xl shadow-lg shadow-black/5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-blue-600/20 flex items-center justify-center text-primary">
                      <FileAudio className="w-7 h-7" />
                    </div>
                    <div>
                      <p className="font-semibold truncate max-w-[200px] text-lg">{file.name}</p>
                      <p className="text-sm text-muted-foreground font-mono">
                        {(file.size / (1024 * 1024)).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={clearFile} disabled={isProcessing} className="rounded-full hover:bg-destructive/10 hover:text-destructive">
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="bg-muted/40 rounded-2xl p-5 flex items-center gap-4 border border-border/50">
                  <Button 
                    size="icon" 
                    className="rounded-full h-12 w-12 bg-primary hover:bg-blue-600 shadow-lg shadow-primary/20 transition-all hover:scale-105 active:scale-95"
                    onClick={togglePlayback}
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                  </Button>
                  <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-primary to-blue-400 w-1/3 rounded-full opacity-80 animate-pulse" /> 
                  </div>
                </div>

                {isProcessing ? (
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm font-medium text-muted-foreground">
                      <span className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-primary" />
                        Processando...
                      </span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2.5 rounded-full" />
                  </div>
                ) : (
                  <Button 
                    className="w-full h-12 text-lg rounded-xl bg-gradient-to-r from-primary to-blue-600 hover:to-blue-700 text-white shadow-lg shadow-primary/20 transition-all hover:shadow-primary/40 hover:scale-[1.02] active:scale-[0.98]" 
                    onClick={handleTranscribe}
                  >
                    <Wand2 className="w-5 h-5 mr-2" />
                    Transcrever Áudio
                  </Button>
                )}
              </Card>
            )}
          </div>

          {/* Right Column: Output */}
          <div className="h-full min-h-[400px] flex flex-col">
            <Card className="flex-1 p-0 overflow-hidden border-0 shadow-xl shadow-black/5 flex flex-col h-full rounded-3xl bg-card ring-1 ring-border/50">
              <div className="p-4 border-b border-border/40 flex items-center justify-between bg-muted/30 backdrop-blur-sm">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur px-3 py-1 rounded-full border border-border/50">Saída de Texto</Badge>
                  {transcription && (
                    <span className="text-xs font-mono text-muted-foreground">
                      {transcription.split(" ").length} palavras
                    </span>
                  )}
                </div>
                <div className="flex gap-1">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    disabled={!transcription} 
                    onClick={handleCopy}
                    className="rounded-full hover:bg-primary/10 hover:text-primary"
                  >
                    {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    disabled={!transcription}
                    onClick={handleDownload}
                    className="rounded-full hover:bg-primary/10 hover:text-primary"
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex-1 relative bg-gradient-to-b from-muted/10 to-transparent">
                <Textarea
                  className="absolute inset-0 w-full h-full resize-none border-0 focus-visible:ring-0 p-8 font-mono text-base leading-relaxed bg-transparent text-foreground/90 selection:bg-primary/20"
                  placeholder="A transcrição aparecerá aqui..."
                  value={transcription}
                  readOnly
                />
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
