import { useState, useEffect, useRef } from "react";
import { Send, Bot, User, Sparkles, Save, History } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createConversation, getConversations, updateConversation } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { createGroqClient, AVAILABLE_MODELS } from "@/lib/groq-client";
import { Card } from "@/components/ui/card";
import { Navbar } from "@/components/layout/navbar";

type Message = {
  role: "user" | "assistant" | "system";
  content: string;
};

export default function Home() {
  const [apiKey, setApiKey] = useState("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");
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [model, setModel] = useState<string>(AVAILABLE_MODELS[0].id);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    const storedKey = localStorage.getItem("groq_api_key");
    if (storedKey) {
      setApiKey(storedKey);
    }
    // Removed the else block that forced settings open
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSaveKey = (key: string) => {
    setApiKey(key);
    localStorage.setItem("groq_api_key", key);
    setIsSettingsOpen(false);
    toast({
      title: "Chave API Salva",
      description: "Sua chave API da Groq foi salva localmente.",
    });
  };

  const saveConversationMutation = useMutation({
    mutationFn: async (msgs: Message[]) => {
      const title = msgs.find(m => m.role === "user")?.content.slice(0, 50) || "Nova conversa";
      if (currentConversationId) {
        return await updateConversation(currentConversationId, { messages: msgs });
      } else {
        return await createConversation({ title, model, messages: msgs });
      }
    },
    onSuccess: (data) => {
      if (!currentConversationId) {
        setCurrentConversationId(data.id);
      }
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    if (!apiKey) {
      setIsSettingsOpen(true);
      return;
    }

    const userMessage: Message = { role: "user", content: input };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput("");
    setIsLoading(true);

    try {
      const groq = createGroqClient(apiKey);
      const chatCompletion = await groq.chat.completions.create({
        messages: [
          { role: "system", content: "Você é um assistente de IA útil e prestativo. Responda sempre em Português do Brasil." },
          ...messages,
          userMessage,
        ],
        model: model,
        temperature: 0.7,
        max_tokens: 1024,
      });

      const assistantMessage = chatCompletion.choices[0]?.message?.content || "";
      const finalMessages = [
        ...updatedMessages,
        { role: "assistant" as const, content: assistantMessage },
      ];
      setMessages(finalMessages);
      
      // Auto-save conversation
      saveConversationMutation.mutate(finalMessages);
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Falha ao obter resposta da Groq. Verifique sua Chave API.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewChat = () => {
    setMessages([]);
    setCurrentConversationId(null);
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground font-sans selection:bg-primary/20">
      {/* Header */}
      <Navbar />

      {/* Chat Area */}
      <ScrollArea className="flex-1 p-4">
        <div className="max-w-3xl mx-auto space-y-6 py-8">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-[50vh] text-center text-muted-foreground space-y-4">
              <div className="h-20 w-20 rounded-3xl bg-primary/10 flex items-center justify-center mb-4 ring-1 ring-primary/20 shadow-[0_0_30px_-10px_var(--color-primary)]">
                <Sparkles className="w-10 h-10 text-primary" />
              </div>
              <h2 className="text-3xl font-bold tracking-tight text-foreground font-display">Trust AI</h2>
              <p className="max-w-md text-lg">
                Inteligência rápida, segura e confiável.
              </p>
              {messages.length === 0 && (
                <Button onClick={handleNewChat} variant="outline" className="mt-4 rounded-full gap-2">
                  <History className="w-4 h-4" />
                  Ver Histórico
                </Button>
              )}
            </div>
          )}
          
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex gap-4 ${
                msg.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              {msg.role === "assistant" && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shrink-0 shadow-md">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              
              <Card
                className={`px-5 py-3.5 max-w-[85%] shadow-sm border-0 ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-2xl rounded-tr-sm"
                    : "bg-muted/50 text-foreground rounded-2xl rounded-tl-sm backdrop-blur-sm"
                }`}
              >
                <div className="text-sm leading-relaxed whitespace-pre-wrap">
                  {msg.content}
                </div>
              </Card>

              {msg.role === "user" && (
                <div className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center shrink-0 border border-border">
                  <User className="w-4 h-4 text-foreground" />
                </div>
              )}
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-4 justify-start">
               <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shrink-0 shadow-md">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <Card className="px-5 py-3.5 bg-muted/50 border-0 rounded-2xl rounded-tl-sm shadow-sm">
                  <div className="flex items-center gap-1.5 h-5">
                    <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-2 h-2 bg-primary/40 rounded-full animate-bounce"></span>
                  </div>
                </Card>
            </div>
          )}
          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 bg-background/80 backdrop-blur-md border-t border-border/40">
        <div className="max-w-3xl mx-auto">
          <form onSubmit={handleSubmit} className="relative flex items-center group">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Digite sua mensagem..."
              className="pr-14 py-6 bg-muted/50 border-transparent focus:bg-background focus:border-primary/30 focus:ring-4 focus:ring-primary/10 shadow-sm rounded-2xl transition-all duration-300"
              disabled={isLoading}
            />
            <Button
              type="submit"
              size="icon"
              className="absolute right-2 h-10 w-10 rounded-xl bg-primary hover:bg-blue-600 text-white transition-all shadow-lg shadow-primary/20 hover:shadow-primary/40 hover:scale-105 active:scale-95"
              disabled={!input.trim() || isLoading}
            >
              <Send className="w-5 h-5" />
            </Button>
          </form>
          <div className="mt-3 text-center">
             <p className="text-[11px] text-muted-foreground font-medium tracking-wide opacity-70">
               TRUST AI • POWERED BY GROQ
             </p>
          </div>
        </div>
      </div>
    </div>
  );
}
