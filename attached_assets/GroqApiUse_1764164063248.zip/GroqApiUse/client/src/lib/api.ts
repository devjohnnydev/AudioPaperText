import type { Conversation, Transcription } from "@shared/schema";

const API_BASE = "/api";

export async function createConversation(data: {
  title: string;
  model: string;
  messages: Array<{ role: string; content: string }>;
}): Promise<Conversation> {
  const res = await fetch(`${API_BASE}/conversations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Failed to create conversation");
  return res.json();
}

export async function getConversations(): Promise<Conversation[]> {
  const res = await fetch(`${API_BASE}/conversations`);
  if (!res.ok) throw new Error("Failed to fetch conversations");
  return res.json();
}

export async function getConversation(id: number): Promise<Conversation> {
  const res = await fetch(`${API_BASE}/conversations/${id}`);
  if (!res.ok) throw new Error("Failed to fetch conversation");
  return res.json();
}

export async function updateConversation(
  id: number,
  data: Partial<{ title: string; messages: Array<{ role: string; content: string }> }>
): Promise<Conversation> {
  const res = await fetch(`${API_BASE}/conversations/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Failed to update conversation");
  return res.json();
}

export async function deleteConversation(id: number): Promise<void> {
  const res = await fetch(`${API_BASE}/conversations/${id}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Failed to delete conversation");
}

export async function createTranscription(data: {
  fileName: string;
  fileSize: string;
  transcriptionText: string;
  model: string;
  wordCount: string;
}): Promise<Transcription> {
  const res = await fetch(`${API_BASE}/transcriptions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Failed to create transcription");
  return res.json();
}

export async function getTranscriptions(): Promise<Transcription[]> {
  const res = await fetch(`${API_BASE}/transcriptions`);
  if (!res.ok) throw new Error("Failed to fetch transcriptions");
  return res.json();
}

export async function deleteTranscription(id: number): Promise<void> {
  const res = await fetch(`${API_BASE}/transcriptions/${id}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Failed to delete transcription");
}
