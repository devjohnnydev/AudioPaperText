import { Groq } from "groq-sdk";

export const createGroqClient = (apiKey: string) => {
  return new Groq({
    apiKey,
    dangerouslyAllowBrowser: true, // Required for frontend-only usage
  });
};

export const AVAILABLE_MODELS = [
  { id: "llama3-8b-8192", name: "Llama 3 8B" },
  { id: "llama3-70b-8192", name: "Llama 3 70B" },
  { id: "mixtral-8x7b-32768", name: "Mixtral 8x7b" },
  { id: "gemma-7b-it", name: "Gemma 7B" },
] as const;
