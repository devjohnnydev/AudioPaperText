import { Link, useLocation } from "wouter";
import { Zap, FileAudio, MessageSquare, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export function Navbar() {
  const [location] = useLocation();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    const storedKey = localStorage.getItem("groq_api_key");
    if (storedKey) setApiKey(storedKey);
  }, []);

  const handleSaveKey = (key: string) => {
    setApiKey(key);
    localStorage.setItem("groq_api_key", key);
    setIsSettingsOpen(false);
    toast({
      title: "API Key Saved",
      description: "Your Groq API key has been saved locally.",
    });
  };

  return (
    <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-10">
      <div className="container max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-primary/10 rounded-md">
            <Zap className="w-5 h-5 text-primary" />
          </div>
          <h1 className="font-semibold tracking-tight text-xl font-display">Trust</h1>
        </div>

        <div className="flex items-center gap-2">
          <nav className="flex items-center gap-1 mr-2">
            <Link href="/">
              <Button
                variant={location === "/" ? "secondary" : "ghost"}
                size="sm"
                className="gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                Chat
              </Button>
            </Link>
            <Link href="/transcribe">
              <Button
                variant={location === "/transcribe" ? "secondary" : "ghost"}
                size="sm"
                className="gap-2"
              >
                <FileAudio className="w-4 h-4" />
                Transcrição
              </Button>
            </Link>
          </nav>

          <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <Settings className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Configuração da API Groq</DialogTitle>
                <DialogDescription>
                  Insira sua chave API da Groq. Ela será armazenada localmente no seu navegador.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Input
                    id="apiKey"
                    type="password"
                    placeholder="gsk_..."
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Você pode obter uma chave API no <a href="https://console.groq.com" target="_blank" rel="noreferrer" className="underline underline-offset-2 hover:text-foreground">Groq Console</a>.
                  </p>
                </div>
                <Button onClick={() => handleSaveKey(apiKey)}>Salvar Chave API</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </header>
  );
}
