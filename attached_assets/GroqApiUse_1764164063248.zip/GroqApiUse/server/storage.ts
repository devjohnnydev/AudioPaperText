import { 
  type User, 
  type InsertUser,
  type Conversation,
  type InsertConversation,
  type Transcription,
  type InsertTranscription,
  users,
  conversations,
  transcriptions
} from "@shared/schema";
import { db } from "../db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversations(): Promise<Conversation[]>;
  getConversation(id: number): Promise<Conversation | undefined>;
  updateConversation(id: number, conversation: Partial<InsertConversation>): Promise<Conversation | undefined>;
  deleteConversation(id: number): Promise<boolean>;
  
  createTranscription(transcription: InsertTranscription): Promise<Transcription>;
  getTranscriptions(): Promise<Transcription[]>;
  getTranscription(id: number): Promise<Transcription | undefined>;
  deleteTranscription(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async createConversation(conversation: InsertConversation): Promise<Conversation> {
    const [created] = await db.insert(conversations).values({
      ...conversation,
      messages: conversation.messages as any
    }).returning();
    return created;
  }

  async getConversations(): Promise<Conversation[]> {
    return await db.select().from(conversations).orderBy(desc(conversations.updatedAt));
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    const [conversation] = await db.select().from(conversations).where(eq(conversations.id, id));
    return conversation;
  }

  async updateConversation(id: number, conversation: Partial<InsertConversation>): Promise<Conversation | undefined> {
    const updateData: any = { ...conversation, updatedAt: new Date() };
    if (conversation.messages) {
      updateData.messages = conversation.messages as any;
    }
    const [updated] = await db
      .update(conversations)
      .set(updateData)
      .where(eq(conversations.id, id))
      .returning();
    return updated;
  }

  async deleteConversation(id: number): Promise<boolean> {
    const result = await db.delete(conversations).where(eq(conversations.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  async createTranscription(transcription: InsertTranscription): Promise<Transcription> {
    const [created] = await db.insert(transcriptions).values(transcription).returning();
    return created;
  }

  async getTranscriptions(): Promise<Transcription[]> {
    return await db.select().from(transcriptions).orderBy(desc(transcriptions.createdAt));
  }

  async getTranscription(id: number): Promise<Transcription | undefined> {
    const [transcription] = await db.select().from(transcriptions).where(eq(transcriptions.id, id));
    return transcription;
  }

  async deleteTranscription(id: number): Promise<boolean> {
    const result = await db.delete(transcriptions).where(eq(transcriptions.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }
}

export const storage = new DatabaseStorage();
